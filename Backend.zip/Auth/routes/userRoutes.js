// import express from "express";
// import UserController from "../controllers/userController.js";
// import checkUserAuth from "../middlewares/auth-middleware.js";

// const router = express.Router();

// //ROUTE LEVEL MIDDLEWARE
// router.post("/changepassword", checkUserAuth);
// router.use("/loggeduser", checkUserAuth);

// //PUBLIC ROUTES
// router.post("/register", UserController.userRegistration);
// router.post("/login", UserController.userLogin);
// router.post(
//   "/send-reset-password-email",
//   UserController.sendUserPasswordResetEmail
// );

// //PROTECTED ROUTES
// router.post("/changepassword", UserController.changeUserPassword);
// router.get("/loggeduser", UserController.loggedUser);

// export default router;

import express from "express";
import UserController from "../controllers/userController.js";
import checkUserAuth from "../middlewares/auth-middleware.js";
import userModel from "../models/User.js";

const router = express.Router();

//ROUTE LEVEL MIDDLEWARE
router.use("/userdata", checkUserAuth);
router.use("/loggeduser", checkUserAuth);

//PUBLIC ROUTES
router.get("/userdata", async (req, res) => {
  const data = await userModel.find();
  res.send(data);
});
router.post("/register", UserController.userRegistration);
router.post("/login", UserController.userLogin);
router.put("/update/:id", async (req, res) => {
  const data = await userModel.findByIdAndUpdate(req.params.id, { $set: req.body });
  res.send(data);
});
router.delete("/delete/:id", async (req, res) => {
  res.send(await userModel.findByIdAndDelete(req.params.id));
});
router.post(
  "/send-reset-password-email",
  UserController.sendUserPasswordResetEmail
);

//PROTECTED ROUTES
router.post("/changepassword/:id", UserController.changeUserPassword);
router.get("/loggeduser", UserController.loggedUser);

export default router;

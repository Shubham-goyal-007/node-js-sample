// import mongoose from "mongoose";

// //SCHEMA
// const userSchema = new mongoose.Schema({
//   name: { type: String, required: true, trim: true },
//   email: { type: String, required: true, trim: true },
//   password: { type: String, required: true, trim: true },
//   tc: { type: Boolean, required: true },
// });

// //MODEL
// const userModel = mongoose.model("user", userSchema);

// export default userModel;

import mongoose from "mongoose";

//SCHEMA
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, trim: true },
  mobile: { type: Number, required: true, trim: true },
  gender: { type: String, required: true, trim: true },
  pwd: { type: String, required: true, trim: true },
  rpwd: { type: String, required: true, trim: true },
  indian: { type: String },
  language: { type: String },
});

//MODEL
const userModel = mongoose.model("formData", userSchema);

export default userModel;

// import dotenv from "dotenv";
// import express from "express";
// import cors from "cors";
// import connectDB from "./config/connectdb.js";
// import userRoutes from "./routes/userRoutes.js";

// const app = express();
// dotenv.config();
// const port = process.env.PORT;

// //CORS
// app.use(cors());

// //DATABASE
// const DATABASE_URL = process.env.DATABASE_URL;
// connectDB(DATABASE_URL);

// //JSON
// app.use(express.json());

// //LOAD ROUTES
// app.use("/api/user", userRoutes);

// app.listen(port, () => {
//   console.log(`Server listening at http://localhost:${port}`);
// });

import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import connectDB from "./config/connectdb.js";
import userRoutes from "./routes/userRoutes.js";

const app = express();
dotenv.config();
const port = process.env.PORT;

//CORS
app.use(cors());
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});

//DATABASE
const DATABASE_URL = process.env.DATABASE_URL;
connectDB(DATABASE_URL);

//JSON
app.use(express.json());

//LOAD ROUTES
app.use("/", userRoutes);

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
